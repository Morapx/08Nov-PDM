//
//  AgregarContactoController.swift
//  Practica_1Nov
//
//  Created by Alumno on 11/8/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class AgregarContactoController: UIViewController{
    
    @IBOutlet weak var txtNombre: UITextField!
    @IBOutlet weak var txtCorreo: UITextField!
    @IBOutlet weak var txtCelular: UITextField!
    
    var callbackAgregarContacto : ((Datos) -> Void)?
    
    override func viewDidLoad() {
        self.title = "Navegar Contacto"
    }
    @IBAction func doTapGuardar(_ sender: Any) {
        let nombre = txtNombre.text!
        let correo = txtCorreo.text!
        let celular = txtCelular.text!
        let datos = Datos(nombre: "", correo: "", numero: "")
        
        callbackAgregarContacto!(datos)
        
        self.navigationController?.popViewController(animated: true)
    }
    
}
