//
//  Datos.swift
//  Practica_1Nov
//
//  Created by Alumno on 11/1/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation

class Datos{
    var nombre = ""
    var correo = ""
    var nunmero = ""
    
    init(nombre: String, correo:String, numero:String){
        self.nombre = nombre
        self.correo = correo
        self.nunmero = numero
    }
}
