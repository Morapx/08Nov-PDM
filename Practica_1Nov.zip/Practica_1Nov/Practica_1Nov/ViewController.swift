//
//  ViewController.swift
//  Practica_1Nov
//
//  Created by Alumno on 11/1/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var datos : [Datos] = []
    
    @IBOutlet weak var tvContactos: UITableView!
    @IBOutlet weak var tvTable: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCell(withIdentifier: "celdaContacto") as! celdadecontactos
        celda.lblNombre.text = datos[indexPath.row].nombre
        celda.lblCorreo.text = datos[indexPath.row].correo
        celda.lblNumero.text = datos[indexPath.row].nunmero
        
        return celda
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToEdicion" {
            
            let datosSeleccionado = datos[tvContactos.indexPathForSelectedRow!.row]
            let destino = segue.destination as! EditarcontactoController
            destino.contacto = datosSeleccionado
            destino.indice = tvContactos.indexPathForSelectedRow!.row
            destino.callbackActualizarTablaContactos = actualizarTablaContactos
            destino.callbackEliminarContacto = eliminarContacto
            
        }
        
        if segue.identifier == "goToCreacion" {
            let destino = segue.destination as! AgregarContactoController
            destino.callbackAgregarContacto = agregarContacto(datoss:)
        }

    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        self.title = "listano se que"
        
        super.viewDidLoad()
        datos.append(Datos(nombre: "Pepe", correo: "Pepe@correo.com", numero: "644118952"))
        datos.append(Datos(nombre: "Jeremy", correo: "Jeremy@correo.com", numero: "644112142"))
        datos.append(Datos(nombre: "Jorge", correo: "Jorge@correo.com", numero: "644111875"))
        
    }

    func actualizarTablaContactos() {
        tvContactos.reloadData()
    }
    
    func eliminarContacto(datos : Datos) {
        datos.remove(at: indice)
        actualizarTablaContactos()
    }
    
    func agregarContacto(datoss : Datos) {
        datos.append(<#T##newElement: Datos##Datos#>)
    }

    
}

