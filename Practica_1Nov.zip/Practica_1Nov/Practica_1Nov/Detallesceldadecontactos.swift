//
//  Detallesceldadecontactos.swift
//  Practica_1Nov
//
//  Created by Alumno on 11/1/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import Foundation
import UIKit

class Detallesceldadecontactos : UIViewController {
    
}
